import { Component } from '@angular/core';
@Component({
  selector: 'app-staff-profile',
  templateUrl: './staff-profile.component.html',
  styleUrls: ['./staff-profile.component.scss'],
})
export class StaffProfileComponent {
  constructor() {
    // constructor code
  }
}
