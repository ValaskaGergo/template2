import { Component } from '@angular/core';
@Component({
  selector: 'app-contact-grid',
  templateUrl: './contact-grid.component.html',
  styleUrls: ['./contact-grid.component.scss'],
})
export class ContactGridComponent {
  constructor() {
    // constructor code
  }
}
